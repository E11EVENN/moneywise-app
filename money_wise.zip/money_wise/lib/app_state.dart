import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {
    prefs = await SharedPreferences.getInstance();
    _safeInit(() {
      _plazoCredito = prefs.getInt('ff_plazoCredito') ?? _plazoCredito;
    });
    _safeInit(() {
      _idUsuario = prefs.getString('ff_idUsuario')?.ref ?? _idUsuario;
    });
    _safeInit(() {
      _idCliente = prefs.getString('ff_idCliente')?.ref ?? _idCliente;
    });
    _safeInit(() {
      _idCredito = prefs.getString('ff_idCredito')?.ref ?? _idCredito;
    });
  }

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  late SharedPreferences prefs;

  double _interes = 0.0;
  double get interes => _interes;
  set interes(double value) {
    _interes = value;
  }

  double _valorCredito = 0.0;
  double get valorCredito => _valorCredito;
  set valorCredito(double value) {
    _valorCredito = value;
  }

  double _totalPago = 0.0;
  double get totalPago => _totalPago;
  set totalPago(double value) {
    _totalPago = value;
  }

  int _plazoCredito = 0;
  int get plazoCredito => _plazoCredito;
  set plazoCredito(int value) {
    _plazoCredito = value;
    prefs.setInt('ff_plazoCredito', value);
  }

  DateTime? _fechaPagoDiario;
  DateTime? get fechaPagoDiario => _fechaPagoDiario;
  set fechaPagoDiario(DateTime? value) {
    _fechaPagoDiario = value;
  }

  DocumentReference? _idUsuario;
  DocumentReference? get idUsuario => _idUsuario;
  set idUsuario(DocumentReference? value) {
    _idUsuario = value;
    value != null
        ? prefs.setString('ff_idUsuario', value.path)
        : prefs.remove('ff_idUsuario');
  }

  DocumentReference? _idCliente;
  DocumentReference? get idCliente => _idCliente;
  set idCliente(DocumentReference? value) {
    _idCliente = value;
    value != null
        ? prefs.setString('ff_idCliente', value.path)
        : prefs.remove('ff_idCliente');
  }

  DocumentReference? _idCredito;
  DocumentReference? get idCredito => _idCredito;
  set idCredito(DocumentReference? value) {
    _idCredito = value;
    value != null
        ? prefs.setString('ff_idCredito', value.path)
        : prefs.remove('ff_idCredito');
  }

  bool _Buscar = false;
  bool get Buscar => _Buscar;
  set Buscar(bool value) {
    _Buscar = value;
  }
}

void _safeInit(Function() initializeField) {
  try {
    initializeField();
  } catch (_) {}
}

Future _safeInitAsync(Function() initializeField) async {
  try {
    await initializeField();
  } catch (_) {}
}
