import '/flutter_flow/flutter_flow_util.dart';
import 'modal_capital_widget.dart' show ModalCapitalWidget;
import 'package:flutter/material.dart';

class ModalCapitalModel extends FlutterFlowModel<ModalCapitalWidget> {
  ///  State fields for stateful widgets in this component.

  // State field(s) for TextFieldCapital widget.
  FocusNode? textFieldCapitalFocusNode;
  TextEditingController? textFieldCapitalTextController;
  String? Function(BuildContext, String?)?
      textFieldCapitalTextControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    textFieldCapitalFocusNode?.dispose();
    textFieldCapitalTextController?.dispose();
  }
}
