import '/flutter_flow/flutter_flow_util.dart';
import 'modal_ayuda_widget.dart' show ModalAyudaWidget;
import 'package:flutter/material.dart';

class ModalAyudaModel extends FlutterFlowModel<ModalAyudaWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
