export 'total_pagar.dart' show totalPagar;
