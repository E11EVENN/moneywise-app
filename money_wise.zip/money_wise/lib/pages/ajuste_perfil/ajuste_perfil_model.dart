import '/flutter_flow/flutter_flow_util.dart';
import 'ajuste_perfil_widget.dart' show AjustePerfilWidget;
import 'package:flutter/material.dart';

class AjustePerfilModel extends FlutterFlowModel<AjustePerfilWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // State field(s) for TextFieldName widget.
  FocusNode? textFieldNameFocusNode;
  TextEditingController? textFieldNameTextController;
  String? Function(BuildContext, String?)? textFieldNameTextControllerValidator;
  // State field(s) for TextFieldToken widget.
  FocusNode? textFieldTokenFocusNode;
  TextEditingController? textFieldTokenTextController;
  String? Function(BuildContext, String?)?
      textFieldTokenTextControllerValidator;
  // State field(s) for TextFieldPhone widget.
  FocusNode? textFieldPhoneFocusNode;
  TextEditingController? textFieldPhoneTextController;
  String? Function(BuildContext, String?)?
      textFieldPhoneTextControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
    textFieldNameFocusNode?.dispose();
    textFieldNameTextController?.dispose();

    textFieldTokenFocusNode?.dispose();
    textFieldTokenTextController?.dispose();

    textFieldPhoneFocusNode?.dispose();
    textFieldPhoneTextController?.dispose();
  }
}
