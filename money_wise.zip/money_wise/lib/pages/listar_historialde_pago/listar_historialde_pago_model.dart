import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'listar_historialde_pago_widget.dart' show ListarHistorialdePagoWidget;
import 'package:flutter/material.dart';

class ListarHistorialdePagoModel
    extends FlutterFlowModel<ListarHistorialdePagoWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // State field(s) for TextFieldBuscar widget.
  FocusNode? textFieldBuscarFocusNode;
  TextEditingController? textFieldBuscarTextController;
  String? Function(BuildContext, String?)?
      textFieldBuscarTextControllerValidator;
  List<RegistrarCreditoRecord> simpleSearchResults = [];

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
    textFieldBuscarFocusNode?.dispose();
    textFieldBuscarTextController?.dispose();
  }
}
