import '/flutter_flow/flutter_flow_util.dart';
import 'login_widget.dart' show LoginWidget;
import 'package:flutter/material.dart';

class LoginModel extends FlutterFlowModel<LoginWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // State field(s) for TabBar widget.
  TabController? tabBarController;
  int get tabBarCurrentIndex =>
      tabBarController != null ? tabBarController!.index : 0;

  // State field(s) for emailAddress_Create widget.
  FocusNode? emailAddressCreateFocusNode;
  TextEditingController? emailAddressCreateTextController;
  String? Function(BuildContext, String?)?
      emailAddressCreateTextControllerValidator;
  // State field(s) for password_Create widget.
  FocusNode? passwordCreateFocusNode;
  TextEditingController? passwordCreateTextController;
  late bool passwordCreateVisibility;
  String? Function(BuildContext, String?)?
      passwordCreateTextControllerValidator;
  // State field(s) for emailAddressInicio widget.
  FocusNode? emailAddressInicioFocusNode;
  TextEditingController? emailAddressInicioTextController;
  String? Function(BuildContext, String?)?
      emailAddressInicioTextControllerValidator;
  // State field(s) for passwordInicio widget.
  FocusNode? passwordInicioFocusNode;
  TextEditingController? passwordInicioTextController;
  late bool passwordInicioVisibility;
  String? Function(BuildContext, String?)?
      passwordInicioTextControllerValidator;

  @override
  void initState(BuildContext context) {
    passwordCreateVisibility = false;
    passwordInicioVisibility = false;
  }

  @override
  void dispose() {
    unfocusNode.dispose();
    tabBarController?.dispose();
    emailAddressCreateFocusNode?.dispose();
    emailAddressCreateTextController?.dispose();

    passwordCreateFocusNode?.dispose();
    passwordCreateTextController?.dispose();

    emailAddressInicioFocusNode?.dispose();
    emailAddressInicioTextController?.dispose();

    passwordInicioFocusNode?.dispose();
    passwordInicioTextController?.dispose();
  }
}
