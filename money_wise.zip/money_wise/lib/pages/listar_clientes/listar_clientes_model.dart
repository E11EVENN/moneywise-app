import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'listar_clientes_widget.dart' show ListarClientesWidget;
import 'package:flutter/material.dart';

class ListarClientesModel extends FlutterFlowModel<ListarClientesWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // State field(s) for TextFieldBuscar widget.
  FocusNode? textFieldBuscarFocusNode;
  TextEditingController? textFieldBuscarTextController;
  String? Function(BuildContext, String?)?
      textFieldBuscarTextControllerValidator;
  List<RegistrarClienteRecord> simpleSearchResults = [];

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
    textFieldBuscarFocusNode?.dispose();
    textFieldBuscarTextController?.dispose();
  }
}
