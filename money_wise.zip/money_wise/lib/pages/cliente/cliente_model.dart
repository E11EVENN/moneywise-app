import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/form_field_controller.dart';
import 'cliente_widget.dart' show ClienteWidget;
import 'package:flutter/material.dart';

class ClienteModel extends FlutterFlowModel<ClienteWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // State field(s) for TextFieldNombre widget.
  FocusNode? textFieldNombreFocusNode;
  TextEditingController? textFieldNombreTextController;
  String? Function(BuildContext, String?)?
      textFieldNombreTextControllerValidator;
  // State field(s) for DropDownTipoIdentificacion widget.
  String? dropDownTipoIdentificacionValue;
  FormFieldController<String>? dropDownTipoIdentificacionValueController;
  // State field(s) for TextFieldIdentificacion widget.
  FocusNode? textFieldIdentificacionFocusNode;
  TextEditingController? textFieldIdentificacionTextController;
  String? Function(BuildContext, String?)?
      textFieldIdentificacionTextControllerValidator;
  // State field(s) for TextFieldDireccion widget.
  FocusNode? textFieldDireccionFocusNode;
  TextEditingController? textFieldDireccionTextController;
  String? Function(BuildContext, String?)?
      textFieldDireccionTextControllerValidator;
  // State field(s) for TextFieldEmail widget.
  FocusNode? textFieldEmailFocusNode;
  TextEditingController? textFieldEmailTextController;
  String? Function(BuildContext, String?)?
      textFieldEmailTextControllerValidator;
  // State field(s) for TextFieldCelular widget.
  FocusNode? textFieldCelularFocusNode;
  TextEditingController? textFieldCelularTextController;
  String? Function(BuildContext, String?)?
      textFieldCelularTextControllerValidator;
  // State field(s) for TextFieldValorCredito widget.
  FocusNode? textFieldValorCreditoFocusNode;
  TextEditingController? textFieldValorCreditoTextController;
  String? Function(BuildContext, String?)?
      textFieldValorCreditoTextControllerValidator;
  // State field(s) for TextFieldFiador widget.
  FocusNode? textFieldFiadorFocusNode;
  TextEditingController? textFieldFiadorTextController;
  String? Function(BuildContext, String?)?
      textFieldFiadorTextControllerValidator;
  bool isDataUploading = false;
  FFUploadedFile uploadedLocalFile =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl = '';

  // State field(s) for TextFieldPrenda widget.
  FocusNode? textFieldPrendaFocusNode;
  TextEditingController? textFieldPrendaTextController;
  String? Function(BuildContext, String?)?
      textFieldPrendaTextControllerValidator;
  // State field(s) for TextFieldValorPrenda widget.
  FocusNode? textFieldValorPrendaFocusNode;
  TextEditingController? textFieldValorPrendaTextController;
  String? Function(BuildContext, String?)?
      textFieldValorPrendaTextControllerValidator;
  // State field(s) for TextFieldInteres widget.
  FocusNode? textFieldInteresFocusNode;
  TextEditingController? textFieldInteresTextController;
  String? Function(BuildContext, String?)?
      textFieldInteresTextControllerValidator;
  // State field(s) for DropDownPeriodo widget.
  String? dropDownPeriodoValue;
  FormFieldController<String>? dropDownPeriodoValueController;
  // State field(s) for TextFieldPazo widget.
  FocusNode? textFieldPazoFocusNode;
  TextEditingController? textFieldPazoTextController;
  String? Function(BuildContext, String?)? textFieldPazoTextControllerValidator;
  // State field(s) for TextFielTotalPago widget.
  FocusNode? textFielTotalPagoFocusNode;
  TextEditingController? textFielTotalPagoTextController;
  String? Function(BuildContext, String?)?
      textFielTotalPagoTextControllerValidator;
  // Stores action output result for [Custom Action - totalPagar] action in Icon widget.
  double? pagar;
  DateTime? datePicked;
  // Stores action output result for [Backend Call - Create Document] action in Button widget.
  RegistrarClienteRecord? clienteCredito;
  // Stores action output result for [Backend Call - Create Document] action in Button widget.
  RegistrarCreditoRecord? datosCredito;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
    textFieldNombreFocusNode?.dispose();
    textFieldNombreTextController?.dispose();

    textFieldIdentificacionFocusNode?.dispose();
    textFieldIdentificacionTextController?.dispose();

    textFieldDireccionFocusNode?.dispose();
    textFieldDireccionTextController?.dispose();

    textFieldEmailFocusNode?.dispose();
    textFieldEmailTextController?.dispose();

    textFieldCelularFocusNode?.dispose();
    textFieldCelularTextController?.dispose();

    textFieldValorCreditoFocusNode?.dispose();
    textFieldValorCreditoTextController?.dispose();

    textFieldFiadorFocusNode?.dispose();
    textFieldFiadorTextController?.dispose();

    textFieldPrendaFocusNode?.dispose();
    textFieldPrendaTextController?.dispose();

    textFieldValorPrendaFocusNode?.dispose();
    textFieldValorPrendaTextController?.dispose();

    textFieldInteresFocusNode?.dispose();
    textFieldInteresTextController?.dispose();

    textFieldPazoFocusNode?.dispose();
    textFieldPazoTextController?.dispose();

    textFielTotalPagoFocusNode?.dispose();
    textFielTotalPagoTextController?.dispose();
  }
}
