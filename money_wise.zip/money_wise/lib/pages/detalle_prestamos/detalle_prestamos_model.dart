import '/flutter_flow/flutter_flow_util.dart';
import 'detalle_prestamos_widget.dart' show DetallePrestamosWidget;
import 'package:flutter/material.dart';

class DetallePrestamosModel extends FlutterFlowModel<DetallePrestamosWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }
}
