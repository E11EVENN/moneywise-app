import '/flutter_flow/flutter_flow_util.dart';
import 'listar_clientes_morosos_widget.dart' show ListarClientesMorososWidget;
import 'package:flutter/material.dart';

class ListarClientesMorososModel
    extends FlutterFlowModel<ListarClientesMorososWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }
}
