// Export pages
export '/pages/home_page/home_page_widget.dart' show HomePageWidget;
export '/pages/login/login_widget.dart' show LoginWidget;
export '/pages/ajuste_perfil/ajuste_perfil_widget.dart' show AjustePerfilWidget;
export '/pages/inicio_app/inicio_app_widget.dart' show InicioAppWidget;
export '/pages/home/home_widget.dart' show HomeWidget;
export '/pages/cliente/cliente_widget.dart' show ClienteWidget;
export '/pages/listar_clientes/listar_clientes_widget.dart'
    show ListarClientesWidget;
export '/pages/detalle_credito/detalle_credito_widget.dart'
    show DetalleCreditoWidget;
export '/pages/cobrodel_dia/cobrodel_dia_widget.dart' show CobrodelDiaWidget;
export '/pages/detalle_capital/detalle_capital_widget.dart'
    show DetalleCapitalWidget;
export '/pages/detalle_prestamos/detalle_prestamos_widget.dart'
    show DetallePrestamosWidget;
export '/pages/detalle_interes/detalle_interes_widget.dart'
    show DetalleInteresWidget;
export '/pages/listar_historialde_pago/listar_historialde_pago_widget.dart'
    show ListarHistorialdePagoWidget;
export '/pages/detalle_historial_pago/detalle_historial_pago_widget.dart'
    show DetalleHistorialPagoWidget;
export '/pages/listar_clientes_cobros_dia/listar_clientes_cobros_dia_widget.dart'
    show ListarClientesCobrosDiaWidget;
export '/pages/listar_clientes_morosos/listar_clientes_morosos_widget.dart'
    show ListarClientesMorososWidget;
export '/pages/listar_clientes_copy/listar_clientes_copy_widget.dart'
    show ListarClientesCopyWidget;
