import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class RegistroPagosRecord extends FirestoreRecord {
  RegistroPagosRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "valorCedito" field.
  double? _valorCedito;
  double get valorCedito => _valorCedito ?? 0.0;
  bool hasValorCedito() => _valorCedito != null;

  // "fechaCredito" field.
  DateTime? _fechaCredito;
  DateTime? get fechaCredito => _fechaCredito;
  bool hasFechaCredito() => _fechaCredito != null;

  // "fechaPago" field.
  DateTime? _fechaPago;
  DateTime? get fechaPago => _fechaPago;
  bool hasFechaPago() => _fechaPago != null;

  // "fechaProximoPago" field.
  DateTime? _fechaProximoPago;
  DateTime? get fechaProximoPago => _fechaProximoPago;
  bool hasFechaProximoPago() => _fechaProximoPago != null;

  // "idReferenciaCredito" field.
  DocumentReference? _idReferenciaCredito;
  DocumentReference? get idReferenciaCredito => _idReferenciaCredito;
  bool hasIdReferenciaCredito() => _idReferenciaCredito != null;

  // "creador" field.
  DocumentReference? _creador;
  DocumentReference? get creador => _creador;
  bool hasCreador() => _creador != null;

  // "fechaCreacion" field.
  DateTime? _fechaCreacion;
  DateTime? get fechaCreacion => _fechaCreacion;
  bool hasFechaCreacion() => _fechaCreacion != null;

  // "idReferenciaCliente" field.
  DocumentReference? _idReferenciaCliente;
  DocumentReference? get idReferenciaCliente => _idReferenciaCliente;
  bool hasIdReferenciaCliente() => _idReferenciaCliente != null;

  // "nombreCliente" field.
  String? _nombreCliente;
  String get nombreCliente => _nombreCliente ?? '';
  bool hasNombreCliente() => _nombreCliente != null;

  // "saldoCredito" field.
  double? _saldoCredito;
  double get saldoCredito => _saldoCredito ?? 0.0;
  bool hasSaldoCredito() => _saldoCredito != null;

  void _initializeFields() {
    _valorCedito = castToType<double>(snapshotData['valorCedito']);
    _fechaCredito = snapshotData['fechaCredito'] as DateTime?;
    _fechaPago = snapshotData['fechaPago'] as DateTime?;
    _fechaProximoPago = snapshotData['fechaProximoPago'] as DateTime?;
    _idReferenciaCredito =
        snapshotData['idReferenciaCredito'] as DocumentReference?;
    _creador = snapshotData['creador'] as DocumentReference?;
    _fechaCreacion = snapshotData['fechaCreacion'] as DateTime?;
    _idReferenciaCliente =
        snapshotData['idReferenciaCliente'] as DocumentReference?;
    _nombreCliente = snapshotData['nombreCliente'] as String?;
    _saldoCredito = castToType<double>(snapshotData['saldoCredito']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('registroPagos');

  static Stream<RegistroPagosRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => RegistroPagosRecord.fromSnapshot(s));

  static Future<RegistroPagosRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => RegistroPagosRecord.fromSnapshot(s));

  static RegistroPagosRecord fromSnapshot(DocumentSnapshot snapshot) =>
      RegistroPagosRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static RegistroPagosRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      RegistroPagosRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'RegistroPagosRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is RegistroPagosRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createRegistroPagosRecordData({
  double? valorCedito,
  DateTime? fechaCredito,
  DateTime? fechaPago,
  DateTime? fechaProximoPago,
  DocumentReference? idReferenciaCredito,
  DocumentReference? creador,
  DateTime? fechaCreacion,
  DocumentReference? idReferenciaCliente,
  String? nombreCliente,
  double? saldoCredito,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'valorCedito': valorCedito,
      'fechaCredito': fechaCredito,
      'fechaPago': fechaPago,
      'fechaProximoPago': fechaProximoPago,
      'idReferenciaCredito': idReferenciaCredito,
      'creador': creador,
      'fechaCreacion': fechaCreacion,
      'idReferenciaCliente': idReferenciaCliente,
      'nombreCliente': nombreCliente,
      'saldoCredito': saldoCredito,
    }.withoutNulls,
  );

  return firestoreData;
}

class RegistroPagosRecordDocumentEquality
    implements Equality<RegistroPagosRecord> {
  const RegistroPagosRecordDocumentEquality();

  @override
  bool equals(RegistroPagosRecord? e1, RegistroPagosRecord? e2) {
    return e1?.valorCedito == e2?.valorCedito &&
        e1?.fechaCredito == e2?.fechaCredito &&
        e1?.fechaPago == e2?.fechaPago &&
        e1?.fechaProximoPago == e2?.fechaProximoPago &&
        e1?.idReferenciaCredito == e2?.idReferenciaCredito &&
        e1?.creador == e2?.creador &&
        e1?.fechaCreacion == e2?.fechaCreacion &&
        e1?.idReferenciaCliente == e2?.idReferenciaCliente &&
        e1?.nombreCliente == e2?.nombreCliente &&
        e1?.saldoCredito == e2?.saldoCredito;
  }

  @override
  int hash(RegistroPagosRecord? e) => const ListEquality().hash([
        e?.valorCedito,
        e?.fechaCredito,
        e?.fechaPago,
        e?.fechaProximoPago,
        e?.idReferenciaCredito,
        e?.creador,
        e?.fechaCreacion,
        e?.idReferenciaCliente,
        e?.nombreCliente,
        e?.saldoCredito
      ]);

  @override
  bool isValidKey(Object? o) => o is RegistroPagosRecord;
}
