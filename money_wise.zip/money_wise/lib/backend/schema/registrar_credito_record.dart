import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class RegistrarCreditoRecord extends FirestoreRecord {
  RegistrarCreditoRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "valorCredito" field.
  double? _valorCredito;
  double get valorCredito => _valorCredito ?? 0.0;
  bool hasValorCredito() => _valorCredito != null;

  // "fiador" field.
  String? _fiador;
  String get fiador => _fiador ?? '';
  bool hasFiador() => _fiador != null;

  // "prenda" field.
  String? _prenda;
  String get prenda => _prenda ?? '';
  bool hasPrenda() => _prenda != null;

  // "imagenPrenda" field.
  String? _imagenPrenda;
  String get imagenPrenda => _imagenPrenda ?? '';
  bool hasImagenPrenda() => _imagenPrenda != null;

  // "valorPrenda" field.
  double? _valorPrenda;
  double get valorPrenda => _valorPrenda ?? 0.0;
  bool hasValorPrenda() => _valorPrenda != null;

  // "porcentajeCredito" field.
  double? _porcentajeCredito;
  double get porcentajeCredito => _porcentajeCredito ?? 0.0;
  bool hasPorcentajeCredito() => _porcentajeCredito != null;

  // "valorInteresMensual" field.
  double? _valorInteresMensual;
  double get valorInteresMensual => _valorInteresMensual ?? 0.0;
  bool hasValorInteresMensual() => _valorInteresMensual != null;

  // "NoCuotas" field.
  double? _noCuotas;
  double get noCuotas => _noCuotas ?? 0.0;
  bool hasNoCuotas() => _noCuotas != null;

  // "periodoPago" field.
  String? _periodoPago;
  String get periodoPago => _periodoPago ?? '';
  bool hasPeriodoPago() => _periodoPago != null;

  // "valorCuota" field.
  double? _valorCuota;
  double get valorCuota => _valorCuota ?? 0.0;
  bool hasValorCuota() => _valorCuota != null;

  // "pagoaCapitalporCuota" field.
  double? _pagoaCapitalporCuota;
  double get pagoaCapitalporCuota => _pagoaCapitalporCuota ?? 0.0;
  bool hasPagoaCapitalporCuota() => _pagoaCapitalporCuota != null;

  // "interesporCuota" field.
  double? _interesporCuota;
  double get interesporCuota => _interesporCuota ?? 0.0;
  bool hasInteresporCuota() => _interesporCuota != null;

  // "pagoaCapital" field.
  double? _pagoaCapital;
  double get pagoaCapital => _pagoaCapital ?? 0.0;
  bool hasPagoaCapital() => _pagoaCapital != null;

  // "deudaActual" field.
  double? _deudaActual;
  double get deudaActual => _deudaActual ?? 0.0;
  bool hasDeudaActual() => _deudaActual != null;

  // "idReferenciaCliente" field.
  DocumentReference? _idReferenciaCliente;
  DocumentReference? get idReferenciaCliente => _idReferenciaCliente;
  bool hasIdReferenciaCliente() => _idReferenciaCliente != null;

  // "fechaCreacion" field.
  DateTime? _fechaCreacion;
  DateTime? get fechaCreacion => _fechaCreacion;
  bool hasFechaCreacion() => _fechaCreacion != null;

  // "creador" field.
  DocumentReference? _creador;
  DocumentReference? get creador => _creador;
  bool hasCreador() => _creador != null;

  // "fechaCredito" field.
  DateTime? _fechaCredito;
  DateTime? get fechaCredito => _fechaCredito;
  bool hasFechaCredito() => _fechaCredito != null;

  // "fechaPago" field.
  DateTime? _fechaPago;
  DateTime? get fechaPago => _fechaPago;
  bool hasFechaPago() => _fechaPago != null;

  // "nombre" field.
  String? _nombre;
  String get nombre => _nombre ?? '';
  bool hasNombre() => _nombre != null;

  void _initializeFields() {
    _valorCredito = castToType<double>(snapshotData['valorCredito']);
    _fiador = snapshotData['fiador'] as String?;
    _prenda = snapshotData['prenda'] as String?;
    _imagenPrenda = snapshotData['imagenPrenda'] as String?;
    _valorPrenda = castToType<double>(snapshotData['valorPrenda']);
    _porcentajeCredito = castToType<double>(snapshotData['porcentajeCredito']);
    _valorInteresMensual =
        castToType<double>(snapshotData['valorInteresMensual']);
    _noCuotas = castToType<double>(snapshotData['NoCuotas']);
    _periodoPago = snapshotData['periodoPago'] as String?;
    _valorCuota = castToType<double>(snapshotData['valorCuota']);
    _pagoaCapitalporCuota =
        castToType<double>(snapshotData['pagoaCapitalporCuota']);
    _interesporCuota = castToType<double>(snapshotData['interesporCuota']);
    _pagoaCapital = castToType<double>(snapshotData['pagoaCapital']);
    _deudaActual = castToType<double>(snapshotData['deudaActual']);
    _idReferenciaCliente =
        snapshotData['idReferenciaCliente'] as DocumentReference?;
    _fechaCreacion = snapshotData['fechaCreacion'] as DateTime?;
    _creador = snapshotData['creador'] as DocumentReference?;
    _fechaCredito = snapshotData['fechaCredito'] as DateTime?;
    _fechaPago = snapshotData['fechaPago'] as DateTime?;
    _nombre = snapshotData['nombre'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('registrarCredito');

  static Stream<RegistrarCreditoRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => RegistrarCreditoRecord.fromSnapshot(s));

  static Future<RegistrarCreditoRecord> getDocumentOnce(
          DocumentReference ref) =>
      ref.get().then((s) => RegistrarCreditoRecord.fromSnapshot(s));

  static RegistrarCreditoRecord fromSnapshot(DocumentSnapshot snapshot) =>
      RegistrarCreditoRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static RegistrarCreditoRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      RegistrarCreditoRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'RegistrarCreditoRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is RegistrarCreditoRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createRegistrarCreditoRecordData({
  double? valorCredito,
  String? fiador,
  String? prenda,
  String? imagenPrenda,
  double? valorPrenda,
  double? porcentajeCredito,
  double? valorInteresMensual,
  double? noCuotas,
  String? periodoPago,
  double? valorCuota,
  double? pagoaCapitalporCuota,
  double? interesporCuota,
  double? pagoaCapital,
  double? deudaActual,
  DocumentReference? idReferenciaCliente,
  DateTime? fechaCreacion,
  DocumentReference? creador,
  DateTime? fechaCredito,
  DateTime? fechaPago,
  String? nombre,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'valorCredito': valorCredito,
      'fiador': fiador,
      'prenda': prenda,
      'imagenPrenda': imagenPrenda,
      'valorPrenda': valorPrenda,
      'porcentajeCredito': porcentajeCredito,
      'valorInteresMensual': valorInteresMensual,
      'NoCuotas': noCuotas,
      'periodoPago': periodoPago,
      'valorCuota': valorCuota,
      'pagoaCapitalporCuota': pagoaCapitalporCuota,
      'interesporCuota': interesporCuota,
      'pagoaCapital': pagoaCapital,
      'deudaActual': deudaActual,
      'idReferenciaCliente': idReferenciaCliente,
      'fechaCreacion': fechaCreacion,
      'creador': creador,
      'fechaCredito': fechaCredito,
      'fechaPago': fechaPago,
      'nombre': nombre,
    }.withoutNulls,
  );

  return firestoreData;
}

class RegistrarCreditoRecordDocumentEquality
    implements Equality<RegistrarCreditoRecord> {
  const RegistrarCreditoRecordDocumentEquality();

  @override
  bool equals(RegistrarCreditoRecord? e1, RegistrarCreditoRecord? e2) {
    return e1?.valorCredito == e2?.valorCredito &&
        e1?.fiador == e2?.fiador &&
        e1?.prenda == e2?.prenda &&
        e1?.imagenPrenda == e2?.imagenPrenda &&
        e1?.valorPrenda == e2?.valorPrenda &&
        e1?.porcentajeCredito == e2?.porcentajeCredito &&
        e1?.valorInteresMensual == e2?.valorInteresMensual &&
        e1?.noCuotas == e2?.noCuotas &&
        e1?.periodoPago == e2?.periodoPago &&
        e1?.valorCuota == e2?.valorCuota &&
        e1?.pagoaCapitalporCuota == e2?.pagoaCapitalporCuota &&
        e1?.interesporCuota == e2?.interesporCuota &&
        e1?.pagoaCapital == e2?.pagoaCapital &&
        e1?.deudaActual == e2?.deudaActual &&
        e1?.idReferenciaCliente == e2?.idReferenciaCliente &&
        e1?.fechaCreacion == e2?.fechaCreacion &&
        e1?.creador == e2?.creador &&
        e1?.fechaCredito == e2?.fechaCredito &&
        e1?.fechaPago == e2?.fechaPago &&
        e1?.nombre == e2?.nombre;
  }

  @override
  int hash(RegistrarCreditoRecord? e) => const ListEquality().hash([
        e?.valorCredito,
        e?.fiador,
        e?.prenda,
        e?.imagenPrenda,
        e?.valorPrenda,
        e?.porcentajeCredito,
        e?.valorInteresMensual,
        e?.noCuotas,
        e?.periodoPago,
        e?.valorCuota,
        e?.pagoaCapitalporCuota,
        e?.interesporCuota,
        e?.pagoaCapital,
        e?.deudaActual,
        e?.idReferenciaCliente,
        e?.fechaCreacion,
        e?.creador,
        e?.fechaCredito,
        e?.fechaPago,
        e?.nombre
      ]);

  @override
  bool isValidKey(Object? o) => o is RegistrarCreditoRecord;
}
