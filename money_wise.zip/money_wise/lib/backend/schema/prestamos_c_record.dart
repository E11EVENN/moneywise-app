import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class PrestamosCRecord extends FirestoreRecord {
  PrestamosCRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "Id_Cliente" field.
  DocumentReference? _idCliente;
  DocumentReference? get idCliente => _idCliente;
  bool hasIdCliente() => _idCliente != null;

  // "Monto" field.
  double? _monto;
  double get monto => _monto ?? 0.0;
  bool hasMonto() => _monto != null;

  // "Interes" field.
  double? _interes;
  double get interes => _interes ?? 0.0;
  bool hasInteres() => _interes != null;

  // "Plazo_Dias" field.
  int? _plazoDias;
  int get plazoDias => _plazoDias ?? 0;
  bool hasPlazoDias() => _plazoDias != null;

  // "Fecha_Inicio" field.
  DateTime? _fechaInicio;
  DateTime? get fechaInicio => _fechaInicio;
  bool hasFechaInicio() => _fechaInicio != null;

  // "Estado" field.
  String? _estado;
  String get estado => _estado ?? '';
  bool hasEstado() => _estado != null;

  // "Pagos" field.
  List<String>? _pagos;
  List<String> get pagos => _pagos ?? const [];
  bool hasPagos() => _pagos != null;

  void _initializeFields() {
    _idCliente = snapshotData['Id_Cliente'] as DocumentReference?;
    _monto = castToType<double>(snapshotData['Monto']);
    _interes = castToType<double>(snapshotData['Interes']);
    _plazoDias = castToType<int>(snapshotData['Plazo_Dias']);
    _fechaInicio = snapshotData['Fecha_Inicio'] as DateTime?;
    _estado = snapshotData['Estado'] as String?;
    _pagos = getDataList(snapshotData['Pagos']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('Prestamos_C');

  static Stream<PrestamosCRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => PrestamosCRecord.fromSnapshot(s));

  static Future<PrestamosCRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => PrestamosCRecord.fromSnapshot(s));

  static PrestamosCRecord fromSnapshot(DocumentSnapshot snapshot) =>
      PrestamosCRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static PrestamosCRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      PrestamosCRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'PrestamosCRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is PrestamosCRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createPrestamosCRecordData({
  DocumentReference? idCliente,
  double? monto,
  double? interes,
  int? plazoDias,
  DateTime? fechaInicio,
  String? estado,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'Id_Cliente': idCliente,
      'Monto': monto,
      'Interes': interes,
      'Plazo_Dias': plazoDias,
      'Fecha_Inicio': fechaInicio,
      'Estado': estado,
    }.withoutNulls,
  );

  return firestoreData;
}

class PrestamosCRecordDocumentEquality implements Equality<PrestamosCRecord> {
  const PrestamosCRecordDocumentEquality();

  @override
  bool equals(PrestamosCRecord? e1, PrestamosCRecord? e2) {
    const listEquality = ListEquality();
    return e1?.idCliente == e2?.idCliente &&
        e1?.monto == e2?.monto &&
        e1?.interes == e2?.interes &&
        e1?.plazoDias == e2?.plazoDias &&
        e1?.fechaInicio == e2?.fechaInicio &&
        e1?.estado == e2?.estado &&
        listEquality.equals(e1?.pagos, e2?.pagos);
  }

  @override
  int hash(PrestamosCRecord? e) => const ListEquality().hash([
        e?.idCliente,
        e?.monto,
        e?.interes,
        e?.plazoDias,
        e?.fechaInicio,
        e?.estado,
        e?.pagos
      ]);

  @override
  bool isValidKey(Object? o) => o is PrestamosCRecord;
}
