// ignore_for_file: unnecessary_getters_setters

import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class BuscarStruct extends FFFirebaseStruct {
  BuscarStruct({
    bool? buscar,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _buscar = buscar,
        super(firestoreUtilData);

  // "Buscar" field.
  bool? _buscar;
  bool get buscar => _buscar ?? true;
  set buscar(bool? val) => _buscar = val;
  bool hasBuscar() => _buscar != null;

  static BuscarStruct fromMap(Map<String, dynamic> data) => BuscarStruct(
        buscar: data['Buscar'] as bool?,
      );

  static BuscarStruct? maybeFromMap(dynamic data) =>
      data is Map ? BuscarStruct.fromMap(data.cast<String, dynamic>()) : null;

  Map<String, dynamic> toMap() => {
        'Buscar': _buscar,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'Buscar': serializeParam(
          _buscar,
          ParamType.bool,
        ),
      }.withoutNulls;

  static BuscarStruct fromSerializableMap(Map<String, dynamic> data) =>
      BuscarStruct(
        buscar: deserializeParam(
          data['Buscar'],
          ParamType.bool,
          false,
        ),
      );

  @override
  String toString() => 'BuscarStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is BuscarStruct && buscar == other.buscar;
  }

  @override
  int get hashCode => const ListEquality().hash([buscar]);
}

BuscarStruct createBuscarStruct({
  bool? buscar,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    BuscarStruct(
      buscar: buscar,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

BuscarStruct? updateBuscarStruct(
  BuscarStruct? buscarStruct, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    buscarStruct
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addBuscarStructData(
  Map<String, dynamic> firestoreData,
  BuscarStruct? buscarStruct,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (buscarStruct == null) {
    return;
  }
  if (buscarStruct.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && buscarStruct.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final buscarStructData = getBuscarFirestoreData(buscarStruct, forFieldValue);
  final nestedData =
      buscarStructData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = buscarStruct.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getBuscarFirestoreData(
  BuscarStruct? buscarStruct, [
  bool forFieldValue = false,
]) {
  if (buscarStruct == null) {
    return {};
  }
  final firestoreData = mapToFirestore(buscarStruct.toMap());

  // Add any Firestore field values
  buscarStruct.firestoreUtilData.fieldValues
      .forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getBuscarListFirestoreData(
  List<BuscarStruct>? buscarStructs,
) =>
    buscarStructs?.map((e) => getBuscarFirestoreData(e, true)).toList() ?? [];
