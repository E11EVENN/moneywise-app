import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class PagosRecord extends FirestoreRecord {
  PagosRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "Id_Prestamo" field.
  DocumentReference? _idPrestamo;
  DocumentReference? get idPrestamo => _idPrestamo;
  bool hasIdPrestamo() => _idPrestamo != null;

  // "Fecha_Pago" field.
  DateTime? _fechaPago;
  DateTime? get fechaPago => _fechaPago;
  bool hasFechaPago() => _fechaPago != null;

  // "Monto" field.
  double? _monto;
  double get monto => _monto ?? 0.0;
  bool hasMonto() => _monto != null;

  // "Estado" field.
  String? _estado;
  String get estado => _estado ?? '';
  bool hasEstado() => _estado != null;

  void _initializeFields() {
    _idPrestamo = snapshotData['Id_Prestamo'] as DocumentReference?;
    _fechaPago = snapshotData['Fecha_Pago'] as DateTime?;
    _monto = castToType<double>(snapshotData['Monto']);
    _estado = snapshotData['Estado'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('Pagos');

  static Stream<PagosRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => PagosRecord.fromSnapshot(s));

  static Future<PagosRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => PagosRecord.fromSnapshot(s));

  static PagosRecord fromSnapshot(DocumentSnapshot snapshot) => PagosRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static PagosRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      PagosRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'PagosRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is PagosRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createPagosRecordData({
  DocumentReference? idPrestamo,
  DateTime? fechaPago,
  double? monto,
  String? estado,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'Id_Prestamo': idPrestamo,
      'Fecha_Pago': fechaPago,
      'Monto': monto,
      'Estado': estado,
    }.withoutNulls,
  );

  return firestoreData;
}

class PagosRecordDocumentEquality implements Equality<PagosRecord> {
  const PagosRecordDocumentEquality();

  @override
  bool equals(PagosRecord? e1, PagosRecord? e2) {
    return e1?.idPrestamo == e2?.idPrestamo &&
        e1?.fechaPago == e2?.fechaPago &&
        e1?.monto == e2?.monto &&
        e1?.estado == e2?.estado;
  }

  @override
  int hash(PagosRecord? e) => const ListEquality()
      .hash([e?.idPrestamo, e?.fechaPago, e?.monto, e?.estado]);

  @override
  bool isValidKey(Object? o) => o is PagosRecord;
}
