import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class UsuariosRecord extends FirestoreRecord {
  UsuariosRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "Tipo_Documento" field.
  String? _tipoDocumento;
  String get tipoDocumento => _tipoDocumento ?? '';
  bool hasTipoDocumento() => _tipoDocumento != null;

  // "Documento" field.
  String? _documento;
  String get documento => _documento ?? '';
  bool hasDocumento() => _documento != null;

  // "Nombre_Y_Apellidos" field.
  String? _nombreYApellidos;
  String get nombreYApellidos => _nombreYApellidos ?? '';
  bool hasNombreYApellidos() => _nombreYApellidos != null;

  // "Telefono_Movil" field.
  String? _telefonoMovil;
  String get telefonoMovil => _telefonoMovil ?? '';
  bool hasTelefonoMovil() => _telefonoMovil != null;

  // "Direccion" field.
  String? _direccion;
  String get direccion => _direccion ?? '';
  bool hasDireccion() => _direccion != null;

  // "Monto_prestamo" field.
  double? _montoPrestamo;
  double get montoPrestamo => _montoPrestamo ?? 0.0;
  bool hasMontoPrestamo() => _montoPrestamo != null;

  // "InteresDePrestamo" field.
  double? _interesDePrestamo;
  double get interesDePrestamo => _interesDePrestamo ?? 0.0;
  bool hasInteresDePrestamo() => _interesDePrestamo != null;

  // "TotalA_Pagar" field.
  double? _totalAPagar;
  double get totalAPagar => _totalAPagar ?? 0.0;
  bool hasTotalAPagar() => _totalAPagar != null;

  // "FechaPrestamo" field.
  DateTime? _fechaPrestamo;
  DateTime? get fechaPrestamo => _fechaPrestamo;
  bool hasFechaPrestamo() => _fechaPrestamo != null;

  // "NotaDePrestamo" field.
  String? _notaDePrestamo;
  String get notaDePrestamo => _notaDePrestamo ?? '';
  bool hasNotaDePrestamo() => _notaDePrestamo != null;

  // "uid" field.
  String? _uid;
  String get uid => _uid ?? '';
  bool hasUid() => _uid != null;

  // "display_name" field.
  String? _displayName;
  String get displayName => _displayName ?? '';
  bool hasDisplayName() => _displayName != null;

  // "photo_url" field.
  String? _photoUrl;
  String get photoUrl => _photoUrl ?? '';
  bool hasPhotoUrl() => _photoUrl != null;

  // "created_time" field.
  DateTime? _createdTime;
  DateTime? get createdTime => _createdTime;
  bool hasCreatedTime() => _createdTime != null;

  // "phone_number" field.
  String? _phoneNumber;
  String get phoneNumber => _phoneNumber ?? '';
  bool hasPhoneNumber() => _phoneNumber != null;

  // "email" field.
  String? _email;
  String get email => _email ?? '';
  bool hasEmail() => _email != null;

  // "perfilCompleto" field.
  bool? _perfilCompleto;
  bool get perfilCompleto => _perfilCompleto ?? false;
  bool hasPerfilCompleto() => _perfilCompleto != null;

  // "capital" field.
  double? _capital;
  double get capital => _capital ?? 0.0;
  bool hasCapital() => _capital != null;

  // "capitalDisponible" field.
  double? _capitalDisponible;
  double get capitalDisponible => _capitalDisponible ?? 0.0;
  bool hasCapitalDisponible() => _capitalDisponible != null;

  // "configuroCapital" field.
  bool? _configuroCapital;
  bool get configuroCapital => _configuroCapital ?? false;
  bool hasConfiguroCapital() => _configuroCapital != null;

  void _initializeFields() {
    _tipoDocumento = snapshotData['Tipo_Documento'] as String?;
    _documento = snapshotData['Documento'] as String?;
    _nombreYApellidos = snapshotData['Nombre_Y_Apellidos'] as String?;
    _telefonoMovil = snapshotData['Telefono_Movil'] as String?;
    _direccion = snapshotData['Direccion'] as String?;
    _montoPrestamo = castToType<double>(snapshotData['Monto_prestamo']);
    _interesDePrestamo = castToType<double>(snapshotData['InteresDePrestamo']);
    _totalAPagar = castToType<double>(snapshotData['TotalA_Pagar']);
    _fechaPrestamo = snapshotData['FechaPrestamo'] as DateTime?;
    _notaDePrestamo = snapshotData['NotaDePrestamo'] as String?;
    _uid = snapshotData['uid'] as String?;
    _displayName = snapshotData['display_name'] as String?;
    _photoUrl = snapshotData['photo_url'] as String?;
    _createdTime = snapshotData['created_time'] as DateTime?;
    _phoneNumber = snapshotData['phone_number'] as String?;
    _email = snapshotData['email'] as String?;
    _perfilCompleto = snapshotData['perfilCompleto'] as bool?;
    _capital = castToType<double>(snapshotData['capital']);
    _capitalDisponible = castToType<double>(snapshotData['capitalDisponible']);
    _configuroCapital = snapshotData['configuroCapital'] as bool?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('Usuarios');

  static Stream<UsuariosRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => UsuariosRecord.fromSnapshot(s));

  static Future<UsuariosRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => UsuariosRecord.fromSnapshot(s));

  static UsuariosRecord fromSnapshot(DocumentSnapshot snapshot) =>
      UsuariosRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static UsuariosRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      UsuariosRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'UsuariosRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is UsuariosRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createUsuariosRecordData({
  String? tipoDocumento,
  String? documento,
  String? nombreYApellidos,
  String? telefonoMovil,
  String? direccion,
  double? montoPrestamo,
  double? interesDePrestamo,
  double? totalAPagar,
  DateTime? fechaPrestamo,
  String? notaDePrestamo,
  String? uid,
  String? displayName,
  String? photoUrl,
  DateTime? createdTime,
  String? phoneNumber,
  String? email,
  bool? perfilCompleto,
  double? capital,
  double? capitalDisponible,
  bool? configuroCapital,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'Tipo_Documento': tipoDocumento,
      'Documento': documento,
      'Nombre_Y_Apellidos': nombreYApellidos,
      'Telefono_Movil': telefonoMovil,
      'Direccion': direccion,
      'Monto_prestamo': montoPrestamo,
      'InteresDePrestamo': interesDePrestamo,
      'TotalA_Pagar': totalAPagar,
      'FechaPrestamo': fechaPrestamo,
      'NotaDePrestamo': notaDePrestamo,
      'uid': uid,
      'display_name': displayName,
      'photo_url': photoUrl,
      'created_time': createdTime,
      'phone_number': phoneNumber,
      'email': email,
      'perfilCompleto': perfilCompleto,
      'capital': capital,
      'capitalDisponible': capitalDisponible,
      'configuroCapital': configuroCapital,
    }.withoutNulls,
  );

  return firestoreData;
}

class UsuariosRecordDocumentEquality implements Equality<UsuariosRecord> {
  const UsuariosRecordDocumentEquality();

  @override
  bool equals(UsuariosRecord? e1, UsuariosRecord? e2) {
    return e1?.tipoDocumento == e2?.tipoDocumento &&
        e1?.documento == e2?.documento &&
        e1?.nombreYApellidos == e2?.nombreYApellidos &&
        e1?.telefonoMovil == e2?.telefonoMovil &&
        e1?.direccion == e2?.direccion &&
        e1?.montoPrestamo == e2?.montoPrestamo &&
        e1?.interesDePrestamo == e2?.interesDePrestamo &&
        e1?.totalAPagar == e2?.totalAPagar &&
        e1?.fechaPrestamo == e2?.fechaPrestamo &&
        e1?.notaDePrestamo == e2?.notaDePrestamo &&
        e1?.uid == e2?.uid &&
        e1?.displayName == e2?.displayName &&
        e1?.photoUrl == e2?.photoUrl &&
        e1?.createdTime == e2?.createdTime &&
        e1?.phoneNumber == e2?.phoneNumber &&
        e1?.email == e2?.email &&
        e1?.perfilCompleto == e2?.perfilCompleto &&
        e1?.capital == e2?.capital &&
        e1?.capitalDisponible == e2?.capitalDisponible &&
        e1?.configuroCapital == e2?.configuroCapital;
  }

  @override
  int hash(UsuariosRecord? e) => const ListEquality().hash([
        e?.tipoDocumento,
        e?.documento,
        e?.nombreYApellidos,
        e?.telefonoMovil,
        e?.direccion,
        e?.montoPrestamo,
        e?.interesDePrestamo,
        e?.totalAPagar,
        e?.fechaPrestamo,
        e?.notaDePrestamo,
        e?.uid,
        e?.displayName,
        e?.photoUrl,
        e?.createdTime,
        e?.phoneNumber,
        e?.email,
        e?.perfilCompleto,
        e?.capital,
        e?.capitalDisponible,
        e?.configuroCapital
      ]);

  @override
  bool isValidKey(Object? o) => o is UsuariosRecord;
}
