import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class AmortizaciondeCreditoRecord extends FirestoreRecord {
  AmortizaciondeCreditoRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "valorCredito" field.
  double? _valorCredito;
  double get valorCredito => _valorCredito ?? 0.0;
  bool hasValorCredito() => _valorCredito != null;

  // "fechaCredito" field.
  DateTime? _fechaCredito;
  DateTime? get fechaCredito => _fechaCredito;
  bool hasFechaCredito() => _fechaCredito != null;

  // "fechaPago" field.
  DateTime? _fechaPago;
  DateTime? get fechaPago => _fechaPago;
  bool hasFechaPago() => _fechaPago != null;

  // "fechaProximoPago" field.
  DateTime? _fechaProximoPago;
  DateTime? get fechaProximoPago => _fechaProximoPago;
  bool hasFechaProximoPago() => _fechaProximoPago != null;

  // "idReferenciaCredito" field.
  DocumentReference? _idReferenciaCredito;
  DocumentReference? get idReferenciaCredito => _idReferenciaCredito;
  bool hasIdReferenciaCredito() => _idReferenciaCredito != null;

  // "idReferenciaCliente" field.
  DocumentReference? _idReferenciaCliente;
  DocumentReference? get idReferenciaCliente => _idReferenciaCliente;
  bool hasIdReferenciaCliente() => _idReferenciaCliente != null;

  // "nombreCliente" field.
  String? _nombreCliente;
  String get nombreCliente => _nombreCliente ?? '';
  bool hasNombreCliente() => _nombreCliente != null;

  // "saldoCredito" field.
  double? _saldoCredito;
  double get saldoCredito => _saldoCredito ?? 0.0;
  bool hasSaldoCredito() => _saldoCredito != null;

  // "creador" field.
  DocumentReference? _creador;
  DocumentReference? get creador => _creador;
  bool hasCreador() => _creador != null;

  // "fechaCreacion" field.
  DateTime? _fechaCreacion;
  DateTime? get fechaCreacion => _fechaCreacion;
  bool hasFechaCreacion() => _fechaCreacion != null;

  // "valorRecaudo" field.
  double? _valorRecaudo;
  double get valorRecaudo => _valorRecaudo ?? 0.0;
  bool hasValorRecaudo() => _valorRecaudo != null;

  // "NoCuota" field.
  double? _noCuota;
  double get noCuota => _noCuota ?? 0.0;
  bool hasNoCuota() => _noCuota != null;

  // "valorCuota" field.
  double? _valorCuota;
  double get valorCuota => _valorCuota ?? 0.0;
  bool hasValorCuota() => _valorCuota != null;

  // "pagoaCapital" field.
  double? _pagoaCapital;
  double get pagoaCapital => _pagoaCapital ?? 0.0;
  bool hasPagoaCapital() => _pagoaCapital != null;

  // "pagoaInteres" field.
  double? _pagoaInteres;
  double get pagoaInteres => _pagoaInteres ?? 0.0;
  bool hasPagoaInteres() => _pagoaInteres != null;

  void _initializeFields() {
    _valorCredito = castToType<double>(snapshotData['valorCredito']);
    _fechaCredito = snapshotData['fechaCredito'] as DateTime?;
    _fechaPago = snapshotData['fechaPago'] as DateTime?;
    _fechaProximoPago = snapshotData['fechaProximoPago'] as DateTime?;
    _idReferenciaCredito =
        snapshotData['idReferenciaCredito'] as DocumentReference?;
    _idReferenciaCliente =
        snapshotData['idReferenciaCliente'] as DocumentReference?;
    _nombreCliente = snapshotData['nombreCliente'] as String?;
    _saldoCredito = castToType<double>(snapshotData['saldoCredito']);
    _creador = snapshotData['creador'] as DocumentReference?;
    _fechaCreacion = snapshotData['fechaCreacion'] as DateTime?;
    _valorRecaudo = castToType<double>(snapshotData['valorRecaudo']);
    _noCuota = castToType<double>(snapshotData['NoCuota']);
    _valorCuota = castToType<double>(snapshotData['valorCuota']);
    _pagoaCapital = castToType<double>(snapshotData['pagoaCapital']);
    _pagoaInteres = castToType<double>(snapshotData['pagoaInteres']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('amortizaciondeCredito');

  static Stream<AmortizaciondeCreditoRecord> getDocument(
          DocumentReference ref) =>
      ref.snapshots().map((s) => AmortizaciondeCreditoRecord.fromSnapshot(s));

  static Future<AmortizaciondeCreditoRecord> getDocumentOnce(
          DocumentReference ref) =>
      ref.get().then((s) => AmortizaciondeCreditoRecord.fromSnapshot(s));

  static AmortizaciondeCreditoRecord fromSnapshot(DocumentSnapshot snapshot) =>
      AmortizaciondeCreditoRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static AmortizaciondeCreditoRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      AmortizaciondeCreditoRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'AmortizaciondeCreditoRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is AmortizaciondeCreditoRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createAmortizaciondeCreditoRecordData({
  double? valorCredito,
  DateTime? fechaCredito,
  DateTime? fechaPago,
  DateTime? fechaProximoPago,
  DocumentReference? idReferenciaCredito,
  DocumentReference? idReferenciaCliente,
  String? nombreCliente,
  double? saldoCredito,
  DocumentReference? creador,
  DateTime? fechaCreacion,
  double? valorRecaudo,
  double? noCuota,
  double? valorCuota,
  double? pagoaCapital,
  double? pagoaInteres,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'valorCredito': valorCredito,
      'fechaCredito': fechaCredito,
      'fechaPago': fechaPago,
      'fechaProximoPago': fechaProximoPago,
      'idReferenciaCredito': idReferenciaCredito,
      'idReferenciaCliente': idReferenciaCliente,
      'nombreCliente': nombreCliente,
      'saldoCredito': saldoCredito,
      'creador': creador,
      'fechaCreacion': fechaCreacion,
      'valorRecaudo': valorRecaudo,
      'NoCuota': noCuota,
      'valorCuota': valorCuota,
      'pagoaCapital': pagoaCapital,
      'pagoaInteres': pagoaInteres,
    }.withoutNulls,
  );

  return firestoreData;
}

class AmortizaciondeCreditoRecordDocumentEquality
    implements Equality<AmortizaciondeCreditoRecord> {
  const AmortizaciondeCreditoRecordDocumentEquality();

  @override
  bool equals(
      AmortizaciondeCreditoRecord? e1, AmortizaciondeCreditoRecord? e2) {
    return e1?.valorCredito == e2?.valorCredito &&
        e1?.fechaCredito == e2?.fechaCredito &&
        e1?.fechaPago == e2?.fechaPago &&
        e1?.fechaProximoPago == e2?.fechaProximoPago &&
        e1?.idReferenciaCredito == e2?.idReferenciaCredito &&
        e1?.idReferenciaCliente == e2?.idReferenciaCliente &&
        e1?.nombreCliente == e2?.nombreCliente &&
        e1?.saldoCredito == e2?.saldoCredito &&
        e1?.creador == e2?.creador &&
        e1?.fechaCreacion == e2?.fechaCreacion &&
        e1?.valorRecaudo == e2?.valorRecaudo &&
        e1?.noCuota == e2?.noCuota &&
        e1?.valorCuota == e2?.valorCuota &&
        e1?.pagoaCapital == e2?.pagoaCapital &&
        e1?.pagoaInteres == e2?.pagoaInteres;
  }

  @override
  int hash(AmortizaciondeCreditoRecord? e) => const ListEquality().hash([
        e?.valorCredito,
        e?.fechaCredito,
        e?.fechaPago,
        e?.fechaProximoPago,
        e?.idReferenciaCredito,
        e?.idReferenciaCliente,
        e?.nombreCliente,
        e?.saldoCredito,
        e?.creador,
        e?.fechaCreacion,
        e?.valorRecaudo,
        e?.noCuota,
        e?.valorCuota,
        e?.pagoaCapital,
        e?.pagoaInteres
      ]);

  @override
  bool isValidKey(Object? o) => o is AmortizaciondeCreditoRecord;
}
