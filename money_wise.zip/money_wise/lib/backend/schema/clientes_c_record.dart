import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ClientesCRecord extends FirestoreRecord {
  ClientesCRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "Tipo_Documento" field.
  String? _tipoDocumento;
  String get tipoDocumento => _tipoDocumento ?? '';
  bool hasTipoDocumento() => _tipoDocumento != null;

  // "Documento" field.
  String? _documento;
  String get documento => _documento ?? '';
  bool hasDocumento() => _documento != null;

  // "Nombre_Y_Apellidos" field.
  String? _nombreYApellidos;
  String get nombreYApellidos => _nombreYApellidos ?? '';
  bool hasNombreYApellidos() => _nombreYApellidos != null;

  // "Telefono_Movil" field.
  String? _telefonoMovil;
  String get telefonoMovil => _telefonoMovil ?? '';
  bool hasTelefonoMovil() => _telefonoMovil != null;

  // "Direccion" field.
  String? _direccion;
  String get direccion => _direccion ?? '';
  bool hasDireccion() => _direccion != null;

  // "Email" field.
  String? _email;
  String get email => _email ?? '';
  bool hasEmail() => _email != null;

  // "Monto_prestamo" field.
  double? _montoPrestamo;
  double get montoPrestamo => _montoPrestamo ?? 0.0;
  bool hasMontoPrestamo() => _montoPrestamo != null;

  // "InteresDePrestamo" field.
  double? _interesDePrestamo;
  double get interesDePrestamo => _interesDePrestamo ?? 0.0;
  bool hasInteresDePrestamo() => _interesDePrestamo != null;

  // "TotalA_Pagar" field.
  double? _totalAPagar;
  double get totalAPagar => _totalAPagar ?? 0.0;
  bool hasTotalAPagar() => _totalAPagar != null;

  // "FechaPrestamo" field.
  DateTime? _fechaPrestamo;
  DateTime? get fechaPrestamo => _fechaPrestamo;
  bool hasFechaPrestamo() => _fechaPrestamo != null;

  void _initializeFields() {
    _tipoDocumento = snapshotData['Tipo_Documento'] as String?;
    _documento = snapshotData['Documento'] as String?;
    _nombreYApellidos = snapshotData['Nombre_Y_Apellidos'] as String?;
    _telefonoMovil = snapshotData['Telefono_Movil'] as String?;
    _direccion = snapshotData['Direccion'] as String?;
    _email = snapshotData['Email'] as String?;
    _montoPrestamo = castToType<double>(snapshotData['Monto_prestamo']);
    _interesDePrestamo = castToType<double>(snapshotData['InteresDePrestamo']);
    _totalAPagar = castToType<double>(snapshotData['TotalA_Pagar']);
    _fechaPrestamo = snapshotData['FechaPrestamo'] as DateTime?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('Clientes_C');

  static Stream<ClientesCRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ClientesCRecord.fromSnapshot(s));

  static Future<ClientesCRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ClientesCRecord.fromSnapshot(s));

  static ClientesCRecord fromSnapshot(DocumentSnapshot snapshot) =>
      ClientesCRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ClientesCRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ClientesCRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ClientesCRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ClientesCRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createClientesCRecordData({
  String? tipoDocumento,
  String? documento,
  String? nombreYApellidos,
  String? telefonoMovil,
  String? direccion,
  String? email,
  double? montoPrestamo,
  double? interesDePrestamo,
  double? totalAPagar,
  DateTime? fechaPrestamo,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'Tipo_Documento': tipoDocumento,
      'Documento': documento,
      'Nombre_Y_Apellidos': nombreYApellidos,
      'Telefono_Movil': telefonoMovil,
      'Direccion': direccion,
      'Email': email,
      'Monto_prestamo': montoPrestamo,
      'InteresDePrestamo': interesDePrestamo,
      'TotalA_Pagar': totalAPagar,
      'FechaPrestamo': fechaPrestamo,
    }.withoutNulls,
  );

  return firestoreData;
}

class ClientesCRecordDocumentEquality implements Equality<ClientesCRecord> {
  const ClientesCRecordDocumentEquality();

  @override
  bool equals(ClientesCRecord? e1, ClientesCRecord? e2) {
    return e1?.tipoDocumento == e2?.tipoDocumento &&
        e1?.documento == e2?.documento &&
        e1?.nombreYApellidos == e2?.nombreYApellidos &&
        e1?.telefonoMovil == e2?.telefonoMovil &&
        e1?.direccion == e2?.direccion &&
        e1?.email == e2?.email &&
        e1?.montoPrestamo == e2?.montoPrestamo &&
        e1?.interesDePrestamo == e2?.interesDePrestamo &&
        e1?.totalAPagar == e2?.totalAPagar &&
        e1?.fechaPrestamo == e2?.fechaPrestamo;
  }

  @override
  int hash(ClientesCRecord? e) => const ListEquality().hash([
        e?.tipoDocumento,
        e?.documento,
        e?.nombreYApellidos,
        e?.telefonoMovil,
        e?.direccion,
        e?.email,
        e?.montoPrestamo,
        e?.interesDePrestamo,
        e?.totalAPagar,
        e?.fechaPrestamo
      ]);

  @override
  bool isValidKey(Object? o) => o is ClientesCRecord;
}
