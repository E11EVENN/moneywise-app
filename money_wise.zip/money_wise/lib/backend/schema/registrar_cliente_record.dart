import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class RegistrarClienteRecord extends FirestoreRecord {
  RegistrarClienteRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "nombre" field.
  String? _nombre;
  String get nombre => _nombre ?? '';
  bool hasNombre() => _nombre != null;

  // "tipoDocumento" field.
  String? _tipoDocumento;
  String get tipoDocumento => _tipoDocumento ?? '';
  bool hasTipoDocumento() => _tipoDocumento != null;

  // "documento" field.
  String? _documento;
  String get documento => _documento ?? '';
  bool hasDocumento() => _documento != null;

  // "diereccion" field.
  String? _diereccion;
  String get diereccion => _diereccion ?? '';
  bool hasDiereccion() => _diereccion != null;

  // "email" field.
  String? _email;
  String get email => _email ?? '';
  bool hasEmail() => _email != null;

  // "celular" field.
  String? _celular;
  String get celular => _celular ?? '';
  bool hasCelular() => _celular != null;

  // "valorCredito" field.
  double? _valorCredito;
  double get valorCredito => _valorCredito ?? 0.0;
  bool hasValorCredito() => _valorCredito != null;

  // "fiador" field.
  String? _fiador;
  String get fiador => _fiador ?? '';
  bool hasFiador() => _fiador != null;

  // "prenda" field.
  String? _prenda;
  String get prenda => _prenda ?? '';
  bool hasPrenda() => _prenda != null;

  // "valorPrenda" field.
  double? _valorPrenda;
  double get valorPrenda => _valorPrenda ?? 0.0;
  bool hasValorPrenda() => _valorPrenda != null;

  // "interes" field.
  double? _interes;
  double get interes => _interes ?? 0.0;
  bool hasInteres() => _interes != null;

  // "totalApagar" field.
  double? _totalApagar;
  double get totalApagar => _totalApagar ?? 0.0;
  bool hasTotalApagar() => _totalApagar != null;

  // "periodo" field.
  String? _periodo;
  String get periodo => _periodo ?? '';
  bool hasPeriodo() => _periodo != null;

  // "plazo" field.
  String? _plazo;
  String get plazo => _plazo ?? '';
  bool hasPlazo() => _plazo != null;

  // "fechaCredito" field.
  DateTime? _fechaCredito;
  DateTime? get fechaCredito => _fechaCredito;
  bool hasFechaCredito() => _fechaCredito != null;

  // "creador" field.
  DocumentReference? _creador;
  DocumentReference? get creador => _creador;
  bool hasCreador() => _creador != null;

  // "fechaCreacion" field.
  DateTime? _fechaCreacion;
  DateTime? get fechaCreacion => _fechaCreacion;
  bool hasFechaCreacion() => _fechaCreacion != null;

  // "imagenPrenda" field.
  String? _imagenPrenda;
  String get imagenPrenda => _imagenPrenda ?? '';
  bool hasImagenPrenda() => _imagenPrenda != null;

  // "saldoCredito" field.
  double? _saldoCredito;
  double get saldoCredito => _saldoCredito ?? 0.0;
  bool hasSaldoCredito() => _saldoCredito != null;

  // "fechaProximoPago" field.
  DateTime? _fechaProximoPago;
  DateTime? get fechaProximoPago => _fechaProximoPago;
  bool hasFechaProximoPago() => _fechaProximoPago != null;

  void _initializeFields() {
    _nombre = snapshotData['nombre'] as String?;
    _tipoDocumento = snapshotData['tipoDocumento'] as String?;
    _documento = snapshotData['documento'] as String?;
    _diereccion = snapshotData['diereccion'] as String?;
    _email = snapshotData['email'] as String?;
    _celular = snapshotData['celular'] as String?;
    _valorCredito = castToType<double>(snapshotData['valorCredito']);
    _fiador = snapshotData['fiador'] as String?;
    _prenda = snapshotData['prenda'] as String?;
    _valorPrenda = castToType<double>(snapshotData['valorPrenda']);
    _interes = castToType<double>(snapshotData['interes']);
    _totalApagar = castToType<double>(snapshotData['totalApagar']);
    _periodo = snapshotData['periodo'] as String?;
    _plazo = snapshotData['plazo'] as String?;
    _fechaCredito = snapshotData['fechaCredito'] as DateTime?;
    _creador = snapshotData['creador'] as DocumentReference?;
    _fechaCreacion = snapshotData['fechaCreacion'] as DateTime?;
    _imagenPrenda = snapshotData['imagenPrenda'] as String?;
    _saldoCredito = castToType<double>(snapshotData['saldoCredito']);
    _fechaProximoPago = snapshotData['fechaProximoPago'] as DateTime?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('registrarCliente');

  static Stream<RegistrarClienteRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => RegistrarClienteRecord.fromSnapshot(s));

  static Future<RegistrarClienteRecord> getDocumentOnce(
          DocumentReference ref) =>
      ref.get().then((s) => RegistrarClienteRecord.fromSnapshot(s));

  static RegistrarClienteRecord fromSnapshot(DocumentSnapshot snapshot) =>
      RegistrarClienteRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static RegistrarClienteRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      RegistrarClienteRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'RegistrarClienteRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is RegistrarClienteRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createRegistrarClienteRecordData({
  String? nombre,
  String? tipoDocumento,
  String? documento,
  String? diereccion,
  String? email,
  String? celular,
  double? valorCredito,
  String? fiador,
  String? prenda,
  double? valorPrenda,
  double? interes,
  double? totalApagar,
  String? periodo,
  String? plazo,
  DateTime? fechaCredito,
  DocumentReference? creador,
  DateTime? fechaCreacion,
  String? imagenPrenda,
  double? saldoCredito,
  DateTime? fechaProximoPago,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'nombre': nombre,
      'tipoDocumento': tipoDocumento,
      'documento': documento,
      'diereccion': diereccion,
      'email': email,
      'celular': celular,
      'valorCredito': valorCredito,
      'fiador': fiador,
      'prenda': prenda,
      'valorPrenda': valorPrenda,
      'interes': interes,
      'totalApagar': totalApagar,
      'periodo': periodo,
      'plazo': plazo,
      'fechaCredito': fechaCredito,
      'creador': creador,
      'fechaCreacion': fechaCreacion,
      'imagenPrenda': imagenPrenda,
      'saldoCredito': saldoCredito,
      'fechaProximoPago': fechaProximoPago,
    }.withoutNulls,
  );

  return firestoreData;
}

class RegistrarClienteRecordDocumentEquality
    implements Equality<RegistrarClienteRecord> {
  const RegistrarClienteRecordDocumentEquality();

  @override
  bool equals(RegistrarClienteRecord? e1, RegistrarClienteRecord? e2) {
    return e1?.nombre == e2?.nombre &&
        e1?.tipoDocumento == e2?.tipoDocumento &&
        e1?.documento == e2?.documento &&
        e1?.diereccion == e2?.diereccion &&
        e1?.email == e2?.email &&
        e1?.celular == e2?.celular &&
        e1?.valorCredito == e2?.valorCredito &&
        e1?.fiador == e2?.fiador &&
        e1?.prenda == e2?.prenda &&
        e1?.valorPrenda == e2?.valorPrenda &&
        e1?.interes == e2?.interes &&
        e1?.totalApagar == e2?.totalApagar &&
        e1?.periodo == e2?.periodo &&
        e1?.plazo == e2?.plazo &&
        e1?.fechaCredito == e2?.fechaCredito &&
        e1?.creador == e2?.creador &&
        e1?.fechaCreacion == e2?.fechaCreacion &&
        e1?.imagenPrenda == e2?.imagenPrenda &&
        e1?.saldoCredito == e2?.saldoCredito &&
        e1?.fechaProximoPago == e2?.fechaProximoPago;
  }

  @override
  int hash(RegistrarClienteRecord? e) => const ListEquality().hash([
        e?.nombre,
        e?.tipoDocumento,
        e?.documento,
        e?.diereccion,
        e?.email,
        e?.celular,
        e?.valorCredito,
        e?.fiador,
        e?.prenda,
        e?.valorPrenda,
        e?.interes,
        e?.totalApagar,
        e?.periodo,
        e?.plazo,
        e?.fechaCredito,
        e?.creador,
        e?.fechaCreacion,
        e?.imagenPrenda,
        e?.saldoCredito,
        e?.fechaProximoPago
      ]);

  @override
  bool isValidKey(Object? o) => o is RegistrarClienteRecord;
}
