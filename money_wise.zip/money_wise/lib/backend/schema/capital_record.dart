import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class CapitalRecord extends FirestoreRecord {
  CapitalRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "capitalInicial" field.
  double? _capitalInicial;
  double get capitalInicial => _capitalInicial ?? 0.0;
  bool hasCapitalInicial() => _capitalInicial != null;

  // "efectivoenCaja" field.
  double? _efectivoenCaja;
  double get efectivoenCaja => _efectivoenCaja ?? 0.0;
  bool hasEfectivoenCaja() => _efectivoenCaja != null;

  // "efectivoTotal" field.
  double? _efectivoTotal;
  double get efectivoTotal => _efectivoTotal ?? 0.0;
  bool hasEfectivoTotal() => _efectivoTotal != null;

  // "utilidad" field.
  double? _utilidad;
  double get utilidad => _utilidad ?? 0.0;
  bool hasUtilidad() => _utilidad != null;

  // "recaudo" field.
  double? _recaudo;
  double get recaudo => _recaudo ?? 0.0;
  bool hasRecaudo() => _recaudo != null;

  // "pendiente" field.
  double? _pendiente;
  double get pendiente => _pendiente ?? 0.0;
  bool hasPendiente() => _pendiente != null;

  // "creador" field.
  DocumentReference? _creador;
  DocumentReference? get creador => _creador;
  bool hasCreador() => _creador != null;

  // "fechaCreacion" field.
  DateTime? _fechaCreacion;
  DateTime? get fechaCreacion => _fechaCreacion;
  bool hasFechaCreacion() => _fechaCreacion != null;

  // "idReferenciaCliente" field.
  DocumentReference? _idReferenciaCliente;
  DocumentReference? get idReferenciaCliente => _idReferenciaCliente;
  bool hasIdReferenciaCliente() => _idReferenciaCliente != null;

  void _initializeFields() {
    _capitalInicial = castToType<double>(snapshotData['capitalInicial']);
    _efectivoenCaja = castToType<double>(snapshotData['efectivoenCaja']);
    _efectivoTotal = castToType<double>(snapshotData['efectivoTotal']);
    _utilidad = castToType<double>(snapshotData['utilidad']);
    _recaudo = castToType<double>(snapshotData['recaudo']);
    _pendiente = castToType<double>(snapshotData['pendiente']);
    _creador = snapshotData['creador'] as DocumentReference?;
    _fechaCreacion = snapshotData['fechaCreacion'] as DateTime?;
    _idReferenciaCliente =
        snapshotData['idReferenciaCliente'] as DocumentReference?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('capital');

  static Stream<CapitalRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => CapitalRecord.fromSnapshot(s));

  static Future<CapitalRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => CapitalRecord.fromSnapshot(s));

  static CapitalRecord fromSnapshot(DocumentSnapshot snapshot) =>
      CapitalRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static CapitalRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      CapitalRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'CapitalRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is CapitalRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createCapitalRecordData({
  double? capitalInicial,
  double? efectivoenCaja,
  double? efectivoTotal,
  double? utilidad,
  double? recaudo,
  double? pendiente,
  DocumentReference? creador,
  DateTime? fechaCreacion,
  DocumentReference? idReferenciaCliente,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'capitalInicial': capitalInicial,
      'efectivoenCaja': efectivoenCaja,
      'efectivoTotal': efectivoTotal,
      'utilidad': utilidad,
      'recaudo': recaudo,
      'pendiente': pendiente,
      'creador': creador,
      'fechaCreacion': fechaCreacion,
      'idReferenciaCliente': idReferenciaCliente,
    }.withoutNulls,
  );

  return firestoreData;
}

class CapitalRecordDocumentEquality implements Equality<CapitalRecord> {
  const CapitalRecordDocumentEquality();

  @override
  bool equals(CapitalRecord? e1, CapitalRecord? e2) {
    return e1?.capitalInicial == e2?.capitalInicial &&
        e1?.efectivoenCaja == e2?.efectivoenCaja &&
        e1?.efectivoTotal == e2?.efectivoTotal &&
        e1?.utilidad == e2?.utilidad &&
        e1?.recaudo == e2?.recaudo &&
        e1?.pendiente == e2?.pendiente &&
        e1?.creador == e2?.creador &&
        e1?.fechaCreacion == e2?.fechaCreacion &&
        e1?.idReferenciaCliente == e2?.idReferenciaCliente;
  }

  @override
  int hash(CapitalRecord? e) => const ListEquality().hash([
        e?.capitalInicial,
        e?.efectivoenCaja,
        e?.efectivoTotal,
        e?.utilidad,
        e?.recaudo,
        e?.pendiente,
        e?.creador,
        e?.fechaCreacion,
        e?.idReferenciaCliente
      ]);

  @override
  bool isValidKey(Object? o) => o is CapitalRecord;
}
