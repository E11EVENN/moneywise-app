import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: const FirebaseOptions(
            apiKey: "AIzaSyBy8eMPztm6-ctpArXqaweefgGiSlTdIZI",
            authDomain: "proyectoucc-hozged.firebaseapp.com",
            projectId: "proyectoucc-hozged",
            storageBucket: "proyectoucc-hozged.appspot.com",
            messagingSenderId: "105493555640",
            appId: "1:105493555640:web:c8fd824f4bd4ad1630074d"));
  } else {
    await Firebase.initializeApp();
  }
}
