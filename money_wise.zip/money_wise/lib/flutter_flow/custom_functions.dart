import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'lat_lng.dart';
import 'place.dart';
import 'uploaded_file.dart';
import '/backend/backend.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '/backend/schema/structs/index.dart';
import '/auth/firebase_auth/auth_util.dart';

double totalaPagar(
  double valorCredito,
  double interes,
  String periodoPago,
  int noCuotas,
) {
  double valorinteres = 0;
  double total = 0;
  double deSemanaAmes = 0;
  double deQuincenaAmes = 0;
  valorinteres = interes / 100;

  if (periodoPago == 'Mensual') {
    total = valorCredito + ((valorCredito * valorinteres) * noCuotas);
  }

  if (periodoPago == 'Quincenal') {
    deSemanaAmes = noCuotas / 2;
    total = valorCredito + (((valorCredito * valorinteres) * deSemanaAmes));
  }

  if (periodoPago == 'Semanal') {
    deSemanaAmes = noCuotas / 4;

    total = valorCredito + ((valorCredito * valorinteres) * deSemanaAmes);
  }

  return total;
}

DateTime fechaProximoPago(
  DateTime fechaPago,
  String periodo,
) {
  int dias = 0;

  if (periodo == 'Mensual') {
    dias = 30;
  }

  if (periodo == 'Quincenal') {
    dias = 15;
  }

  if (periodo == 'Semanal') {
    dias = 7;
  }

  return fechaPago.add(Duration(days: dias));
  // return fechaPago.add(Duration(days: plazo));
}

double calcularCapitalDisponible(
  double capitalDiponible,
  double valorCredito,
) {
  return capitalDiponible - valorCredito;
}

DateTime fechaProximoPagoAmorti(
  DateTime fechaPago,
  String periodo,
) {
  int dias = 0;
  if (periodo == 'Mensual') {
    dias = 30;
  }
  if (periodo == 'Quincenal') {
    dias = 15;
  }

  if (periodo == 'Semanal') {
    dias = 8;
  }
  return fechaPago.add(Duration(days: dias));
}

double valorCuota(
  double valorPrestamo,
  double porInteres,
  double numCuotas,
  String periodoPago,
) {
  double intereese = 0;
  double valorinteresMensual = 0;
  //double valorCredito;
  double totalPagar = 0;
  //double valorCuotaMensual = 0;
  double cuota = 0;
  double dequinceaMes = 0;
  double desemanaaMes = 0;

  double interesApagar = 0;

  double interesBruto = 0;
  //double valorCuotaQuincenal = 0;

  intereese = porInteres / 100;
  valorinteresMensual = valorPrestamo * intereese;

  totalPagar = (valorinteresMensual * numCuotas) + valorPrestamo;

  if (periodoPago == 'Mensual') {
    intereese = porInteres / 100;
    valorinteresMensual = valorPrestamo * intereese;

    totalPagar = (valorinteresMensual * numCuotas) + valorPrestamo;
    cuota = totalPagar / numCuotas;
  }

  if (periodoPago == 'Quincenal') {
    dequinceaMes = numCuotas / 2;

    intereese = porInteres / 100;

    valorinteresMensual = valorPrestamo * intereese;

    interesBruto = valorinteresMensual * dequinceaMes;

    interesApagar = interesBruto / numCuotas;

    totalPagar = interesBruto + valorPrestamo;

    cuota = totalPagar / numCuotas;
  }

  if (periodoPago == 'Semanal') {
    desemanaaMes = numCuotas / 4;

    intereese = porInteres / 100;

    valorinteresMensual = valorPrestamo * intereese;

    interesBruto = valorinteresMensual * desemanaaMes;

    interesApagar = interesBruto / numCuotas;

    totalPagar = (valorPrestamo / numCuotas) + interesApagar;
    cuota = totalPagar;
  }

  return cuota;
}

double cuotasCapital(
  double valorCredito,
  double noCuotas,
) {
  return valorCredito / noCuotas;
}

double coutasInteres(
  double valorPrestamo,
  double porcenInter,
  double numCuotas,
  String periodoPago,
) {
  double intereese = 0;
  double valorinteresMensual = 0;
  double pagarInteres = 0;
  double dequinceaMes = 0;
  double deSemanaaMes = 0;
  double totalInteresApagar = 0;

  if (periodoPago == 'Mensual') {
    intereese = porcenInter / 100;

    valorinteresMensual = (valorPrestamo * intereese) * numCuotas;

    totalInteresApagar = valorinteresMensual / numCuotas;
  }

  if (periodoPago == 'Quincenal') {
    intereese = porcenInter / 100;

    dequinceaMes = numCuotas / 2;

    valorinteresMensual = valorPrestamo * intereese;

    pagarInteres = valorinteresMensual * dequinceaMes;

    totalInteresApagar = pagarInteres / numCuotas;
  }
  if (periodoPago == 'Semanal') {
    intereese = porcenInter / 100;

    deSemanaaMes = numCuotas / 4;

    valorinteresMensual = valorPrestamo * intereese;
    totalInteresApagar = valorinteresMensual / numCuotas;
  }

  //return valorinteresMensual / numCuotas;
  return totalInteresApagar;
}

double actualizaEfectivoCaja(
  double efectivoCaja,
  double valorCredito,
) {
  return efectivoCaja - valorCredito;
}

double actualizarDeudaActual(
  double valorDeuda,
  double cuota,
) {
  return valorDeuda - cuota;
}

double sumaEfectivoCaja(
  double valorEfectivoCaja,
  double recuado,
) {
  return valorEfectivoCaja + recuado;
}

double sumaUtilidad(
  double valorUtilidad,
  double valorInteres,
) {
  return valorUtilidad + valorInteres;
}

double sumaEfectivoTotal(
  double valorEfectivoTotal,
  double valorInteres,
) {
  return valorEfectivoTotal + valorInteres;
}

double sumarRecaudo(
  double valorRecaudo,
  double valorCuota,
) {
  return valorRecaudo + valorCuota;
}

double diferenciaEnDias(
  DateTime fechaStr1,
  DateTime fechaStr2,
) {
  double dias = 0;
  var mili = 0;
// return time difference between meetingEndTime and currentTime
  final difference = fechaStr2.difference(fechaStr1);
  mili = math.max(0, difference.inMilliseconds).abs();
  dias = mili / 86400000;
  return dias;
}
