package com.mycompany.proyectoucc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
